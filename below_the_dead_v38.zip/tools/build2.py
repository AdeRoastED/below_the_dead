import json, pickle, numpy as np
from PIL import Image
D = pickle.load(open('sliced2.pkl','rb'))
def fr(k,r,i):
    b,sz,x,y = D[k][r][i]; return Image.frombytes('RGBA',sz,b),x,y
def rowbase(k,r): return np.median([y+sz[1] for (b,sz,x,y) in D[k][r]])
def build(name, anims, groups, u, center=True):
    # groups: {sheetkey: target height for ref median of that sheet's frames used in anim listed in 'ref'}
    out=[]; seq={}; cache={}
    for an, lst in anims:
        seq[an]=[]
        for (k,r,i) in lst:
            key=(k,r,i)
            if key not in cache:
                im,x,y=fr(k,r,i); s=groups[k]
                base=rowbase(k,r)-y
                ax=im.width/2
                im2=im.resize((max(1,round(im.width*s)),max(1,round(im.height*s))),Image.LANCZOS)
                cache[key]=len(out); out.append((im2,ax*s,base*s))
            seq[an].append(cache[key])
    W=sum(o[0].width+2 for o in out); H=max(o[0].height for o in out)
    at=Image.new('RGBA',(W,H),(0,0,0,0)); F=[]; x=0
    for im,ax,ay in out: at.paste(im,(x,0)); F.append([x,0,im.width,im.height,round(ax),round(ay)]); x+=im.width+2
    at.save(f'/home/claude/v37/sprites/{name}.webp','WEBP',quality=86,method=4)
    return {'f':F,'s':seq,'u':u}
SPR={}
SPR['rocco']=build('rocco',[
 ('idle',[('r_idle',0,i) for i in (2,3,4,5)]),('worried',[('r_idle',1,i) for i in (1,2,3,4)]),
 ('shout',[('r_shout',0,i) for i in (0,3,4)]),('angry',[('r_shout',1,i) for i in (0,3,4)]),
 ('cook',[('r_cook',0,i) for i in range(6)])],
 {'r_idle':136/326,'r_shout':136/327,'r_cook':150/638},0.5)
SPR['robodog']=build('robodog',[
 ('run',[('d_run',0,i) for i in range(6)]),('lunge',[('d_run',1,i) for i in (1,2,3)]),('stand',[('d_run',1,0)]),
 ('hit',[('d_hit',0,i) for i in (0,1,2)]),('die',[('d_hit',0,2),('d_hit',0,3)]),('taunt',[('d_hit',1,i) for i in (1,2,3,4)])],
 {'d_run':110/282,'d_hit':110/282},0.42)
SPR['arms']=build('arms',[('robot',[('arms',0,0)]),('fake',[('arms',0,1)])],{'arms':90/466},0.5)
json.dump(SPR,open('spr2.json','w'),separators=(',',':'))
print({k:{a:len(v) for a,v in S['s'].items()} for k,S in SPR.items()})
