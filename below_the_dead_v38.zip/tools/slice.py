"""Sprite sheet slicer: key background (magenta/green, with unmixing), drop grid lines,
find figures (connected blobs, small bits merged into nearest figure), group into rows."""
import numpy as np
from PIL import Image
from scipy import ndimage as ndi


def key_image(path):
    im = np.asarray(Image.open(path).convert('RGB')).astype(np.float32)
    H, W, _ = im.shape
    border = np.concatenate([im[:4].reshape(-1, 3), im[-4:].reshape(-1, 3), im[:, :4].reshape(-1, 3), im[:, -4:].reshape(-1, 3)])
    K = np.median(border, axis=0)
    green = K[1] > K[0] and K[1] > K[2]
    d = np.sqrt(((im - K) ** 2).sum(-1))
    # chroma-based alpha: how much of the key "hue" is present
    if green:
        spill = im[..., 1] - np.maximum(im[..., 0], im[..., 2])
    else:
        spill = np.minimum(im[..., 0], im[..., 2]) - im[..., 1]
    t0, t1 = 60.0, 150.0
    a = np.clip((d - t0) / (t1 - t0), 0, 1)
    a = np.where(spill > 150, 0, a)
    # unmix: c = a*f + (1-a)*K
    af = np.maximum(a, 1e-3)[..., None]
    f = np.clip((im - (1 - a)[..., None] * K) / af, 0, 255)
    # despill residual key tint on edges
    if green:
        f[..., 1] = np.minimum(f[..., 1], np.maximum(f[..., 0], f[..., 2]) + 10)
    else:
        lim = f[..., 1] + 25
        hi = (f[..., 0] > lim) & (f[..., 2] > lim)
        m = np.minimum(f[..., 0], f[..., 2])
        f[..., 0] = np.where(hi, f[..., 0] - (m - lim) * 0.8, f[..., 0])
        f[..., 2] = np.where(hi, f[..., 2] - (m - lim) * 0.8, f[..., 2])
    # grid lines: thin rows/cols that are mostly opaque across the whole image
    op = a > 0.5
    rowfrac = op.mean(1)
    colfrac = op.mean(0)
    lum = im.mean(-1)
    for y in np.where(rowfrac > 0.9)[0]:
        if np.median(lum[y]) < 110:
            a[max(0, y - 1):y + 2] = 0
    for x in np.where(colfrac > 0.9)[0]:
        if np.median(lum[:, x]) < 110:
            a[:, max(0, x - 1):x + 2] = 0
    return f, a, green


def find_frames(a, min_area=1500, gap=6):
    H, W = a.shape
    mask = a > 0.35
    mask = ndi.binary_opening(mask, iterations=1)
    lab, n = ndi.label(ndi.binary_dilation(mask, iterations=gap))
    objs = ndi.find_objects(lab)
    blobs = []
    for i, sl in enumerate(objs):
        if sl is None:
            continue
        area = int((mask[sl] & (lab[sl] == i + 1)).sum())
        blobs.append(dict(id=i + 1, y0=sl[0].start, y1=sl[0].stop, x0=sl[1].start, x1=sl[1].stop, area=area))
    big = [b for b in blobs if b['area'] >= min_area]
    small = [b for b in blobs if 30 <= b['area'] < min_area]
    # merge small bits into nearest big blob (by bbox distance)
    for s in small:
        cx, cy = (s['x0'] + s['x1']) / 2, (s['y0'] + s['y1']) / 2
        best, bd = None, 1e9
        for b in big:
            dx = max(b['x0'] - cx, 0, cx - b['x1'])
            dy = max(b['y0'] - cy, 0, cy - b['y1'])
            dd = dx + dy * 2
            if dd < bd:
                bd, best = dd, b
        if best is not None and bd < 140:
            best.setdefault('extra', []).append(s)
    # rows: cluster by vertical center
    big.sort(key=lambda b: (b['y0'] + b['y1']) / 2)
    rows = []
    for b in big:
        cy = (b['y0'] + b['y1']) / 2
        if rows and abs(cy - rows[-1]['cy']) < 0.35 * (b['y1'] - b['y0'] + 40):
            rows[-1]['items'].append(b)
            rows[-1]['cy'] = np.mean([(x['y0'] + x['y1']) / 2 for x in rows[-1]['items']])
        else:
            rows.append(dict(cy=cy, items=[b]))
    for r in rows:
        r['items'].sort(key=lambda b: b['x0'])
    return lab, rows


def crop(f, a, lab, b):
    ids = [b['id']] + [e['id'] for e in b.get('extra', [])]
    x0 = min([b['x0']] + [e['x0'] for e in b.get('extra', [])])
    x1 = max([b['x1']] + [e['x1'] for e in b.get('extra', [])])
    y0 = min([b['y0']] + [e['y0'] for e in b.get('extra', [])])
    y1 = max([b['y1']] + [e['y1'] for e in b.get('extra', [])])
    L = lab[y0:y1, x0:x1]
    m = np.isin(L, ids)
    al = np.where(m, a[y0:y1, x0:x1], 0)
    al = np.where(al < 0.06, 0, al)
    rgba = np.dstack([f[y0:y1, x0:x1], al * 255]).astype(np.uint8)
    im = Image.fromarray(rgba, 'RGBA')
    bb = im.getbbox()
    if bb:
        im = im.crop(bb)
        x0 += bb[0]
        y0 += bb[1]
    return im, x0, y0


def slice_sheet(path, min_area=1500):
    f, a, green = key_image(path)
    lab, rows = find_frames(a, min_area=min_area)
    out = []
    for r in rows:
        fr = []
        for b in r['items']:
            im, x0, y0 = crop(f, a, lab, b)
            fr.append(dict(im=im, x=x0, y=y0))
        out.append(fr)
    return out


def _bands(prof, thr, mergegap, minsize):
    on = prof > thr
    bands = []
    i = 0
    n = len(prof)
    while i < n:
        if on[i]:
            j = i
            while j < n and on[j]:
                j += 1
            bands.append([i, j])
            i = j
        else:
            i += 1
    merged = []
    for b in bands:
        if merged and b[0] - merged[-1][1] < mergegap:
            merged[-1][1] = b[1]
        else:
            merged.append(b)
    return merged


def _absorb_small(bands, mass, minsize, minmass):
    # merge bands that are too small into the nearest neighbour
    changed = True
    while changed and len(bands) > 1:
        changed = False
        for i, b in enumerate(bands):
            if (b[1] - b[0]) < minsize or mass(b) < minmass:
                if i == 0:
                    j = 1
                elif i == len(bands) - 1:
                    j = i - 1
                else:
                    j = i - 1 if (b[0] - bands[i - 1][1]) <= (bands[i + 1][0] - b[1]) else i + 1
                lo, hi = min(i, j), max(i, j)
                bands[lo] = [min(bands[lo][0], bands[hi][0]), max(bands[lo][1], bands[hi][1])]
                del bands[hi]
                changed = True
                break
    return bands


def slice_grid(path, row_minsize=90, col_minsize=30, col_minmass=1200, colgap=5):
    f, a, green = key_image(path)
    mask = ndi.binary_opening(a > 0.4, iterations=1)
    H, W = mask.shape
    rp = mask.sum(1)
    rows = _bands(rp, 2, 10, 0)
    rows = _absorb_small(rows, lambda b: int(rp[b[0]:b[1]].sum()), row_minsize, 4000)
    out = []
    for r0, r1 in rows:
        m = mask[r0:r1]
        cp = m.sum(0)
        cols = _bands(cp, 0, colgap, 0)
        cols = _absorb_small(cols, lambda b: int(cp[b[0]:b[1]].sum()), col_minsize, col_minmass)
        fr = []
        for c0, c1 in cols:
            al = a[r0:r1, c0:c1].copy()
            al = np.where(al < 0.06, 0, al)
            rgba = np.dstack([f[r0:r1, c0:c1], al * 255]).astype(np.uint8)
            im = Image.fromarray(rgba, 'RGBA')
            bb = im.getbbox()
            if not bb:
                continue
            im = im.crop(bb)
            fr.append(dict(im=im, x=c0 + bb[0], y=r0 + bb[1], rowbottom=r1))
        out.append(fr)
    return out


def slice_rows(path, nrows, colgap=5, relmass=0.22, minw=26):
    f, a, green = key_image(path)
    mask = ndi.binary_opening(a > 0.4, iterations=1)
    H, W = mask.shape
    rp = mask.sum(1).astype(float)
    sm = np.convolve(rp, np.ones(9) / 9, 'same')
    cuts = [0]
    for i in range(1, nrows):
        c = H * i / nrows
        lo, hi = int(c - H / nrows * 0.35), int(c + H / nrows * 0.35)
        cuts.append(lo + int(np.argmin(sm[lo:hi])))
    cuts.append(H)
    out = []
    for r in range(nrows):
        r0, r1 = cuts[r], cuts[r + 1]
        m = mask[r0:r1]
        cp = m.sum(0).astype(float)
        cols = _bands(cp, 0, colgap, 0)
        masses = [cp[c0:c1].sum() for c0, c1 in cols]
        if not masses:
            out.append([]); continue
        big = np.median(sorted(masses)[len(masses) // 2:]) if len(masses) > 1 else masses[0]
        cols = _absorb_small(cols, lambda b: float(cp[b[0]:b[1]].sum()), minw, relmass * big)
        # split overly wide segments at the weakest column
        ws = [c1 - c0 for c0, c1 in cols]
        med = np.median(ws)
        res = []
        for c0, c1 in cols:
            if c1 - c0 > med * 1.75 and len(cols) > 2:
                seg = np.convolve(cp[c0:c1], np.ones(7) / 7, 'same')
                lo, hi = int((c1 - c0) * 0.3), int((c1 - c0) * 0.7)
                k = c0 + lo + int(np.argmin(seg[lo:hi]))
                res += [[c0, k], [k, c1]]
            else:
                res.append([c0, c1])
        fr = []
        for c0, c1 in res:
            al = a[r0:r1, c0:c1].copy()
            al = np.where(al < 0.06, 0, al)
            rgba = np.dstack([f[r0:r1, c0:c1], al * 255]).astype(np.uint8)
            im = Image.fromarray(rgba, 'RGBA')
            bb = im.getbbox()
            if not bb:
                continue
            im = im.crop(bb)
            fr.append(dict(im=im, x=c0 + bb[0], y=r0 + bb[1], rowbottom=r1))
        out.append(fr)
    return out


def slice_fixed(path, layout):
    """layout = list of column counts per row; cuts placed at profile minima near even spacing."""
    f, a, green = key_image(path)
    mask = ndi.binary_opening(a > 0.4, iterations=1)
    H, W = mask.shape
    nrows = len(layout)
    rp = np.convolve(mask.sum(1).astype(float), np.ones(9) / 9, 'same')
    cuts = [0]
    for i in range(1, nrows):
        c = H * i / nrows; lo, hi = int(c - H / nrows * 0.35), int(c + H / nrows * 0.35)
        cuts.append(lo + int(np.argmin(rp[lo:hi])))
    cuts.append(H)
    out = []
    for r, n in enumerate(layout):
        r0, r1 = cuts[r], cuts[r + 1]
        cp = mask[r0:r1].sum(0).astype(float)
        nz = np.where(cp > 0)[0]
        x0, x1 = (nz[0], nz[-1] + 1) if len(nz) else (0, W)
        sm = np.convolve(cp, np.ones(11) / 11, 'same')
        cc = [x0]
        for i in range(1, n):
            c = x0 + (x1 - x0) * i / n; span = (x1 - x0) / n * 0.4
            lo, hi = int(c - span), int(c + span)
            cc.append(lo + int(np.argmin(sm[lo:hi])))
        cc.append(x1)
        fr = []
        for c0, c1 in zip(cc[:-1], cc[1:]):
            al = np.where(a[r0:r1, c0:c1] < 0.06, 0, a[r0:r1, c0:c1])
            im = Image.fromarray(np.dstack([f[r0:r1, c0:c1], al * 255]).astype(np.uint8), 'RGBA')
            bb = im.getbbox()
            if not bb: continue
            fr.append(dict(im=im.crop(bb), x=c0 + bb[0], y=r0 + bb[1], rowbottom=r1))
        out.append(fr)
    return out
