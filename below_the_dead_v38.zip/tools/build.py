import json, pickle, sys
import numpy as np
from PIL import Image

D = pickle.load(open('/home/claude/art/sliced.pkl', 'rb'))
OUT = sys.argv[1]  # sprites dir
SIDE = {'ben': (0.6046, 138), 'chloe': (0.4882, 136), 'aris': (0.5079, 135), 'leo': (0.5, 138)}
FLIP = {'ben_FD': -1}
FIRE = {'shotgun': 1, 'smg': 3, 'flamer': 2}


def frames(k):
    return [[(Image.frombytes('RGBA', sz, b), x, y) for (b, sz, x, y) in row] for row in D[k]]


def torso_x(im, base_rel, H):
    a = np.asarray(im)[..., 3] > 128
    y0, y1 = int(max(0, base_rel - 0.62 * H)), int(max(1, base_rel - 0.25 * H))
    band = a[y0:y1]
    xs = np.where(band)[1]
    if len(xs) < 20:
        xs = np.where(a)[1]
    return float(np.median(xs)) if len(xs) else im.width / 2


def build(k, anims, ref):
    """anims: list of (name, [(row, idx, mirror)])"""
    R = frames(k)
    refh = np.median([R[r][i][0].height for r, i in ref])
    s = 136.0 / refh
    rowbase = [np.median([y + im.height for im, x, y in row]) for row in R]
    out_frames, idx_map, seq = [], {}, {}
    for name, lst in anims:
        seq[name] = []
        for r, i, mir in lst:
            key = (r, i, mir)
            if key not in idx_map:
                im, x, y = R[r][i]
                base_rel = rowbase[r] - y
                stand = refh
                ax = im.width / 2 if name == 'die' else torso_x(im, base_rel, stand)
                if mir:
                    im = im.transpose(Image.FLIP_LEFT_RIGHT); ax = im.width - ax
                w, h = max(1, round(im.width * s)), max(1, round(im.height * s))
                im2 = im.resize((w, h), Image.LANCZOS)
                idx_map[key] = len(out_frames)
                out_frames.append((im2, ax * s, base_rel * s))
            seq[name].append(idx_map[key])
    W = sum(f[0].width + 2 for f in out_frames)
    Hh = max(f[0].height for f in out_frames)
    atlas = Image.new('RGBA', (W, Hh), (0, 0, 0, 0))
    F = []
    x = 0
    for im, ax, ay in out_frames:
        atlas.paste(im, (x, 0))
        F.append([x, 0, im.width, im.height, round(ax), round(ay)])
        x += im.width + 2
    atlas.save(f'{OUT}/{k}.webp', 'WEBP', quality=86, method=6)
    hero = k.split('_')[1] if k.startswith('w_') else k.split('_')[0]
    u0, h0 = SIDE[hero]
    entry = {'f': F, 's': seq, 'u': round(u0 * h0 / 136.0, 4)}
    if k in FLIP:
        entry['flip'] = FLIP[k]
    return entry


def base_anims(k):
    R = D[k]
    n3 = len(R[2])
    hit_i = n3 - 1
    if k == 'ben_B':
        hit_i = 5
    mir_aim = (k == 'ben_B')
    an = [('idle', [(0, i, False) for i in range(min(6, len(R[0])))]),
          ('walk', [(1, i, False) for i in range(len(R[1]))]),
          ('aim', [(2, i, mir_aim) for i in range(4)]),
          ('hit', [(2, hit_i, False)]),
          ('die', [(3, i, False) for i in range(len(R[3]))])]
    ref = [(0, i) for i in range(len(R[0]))]
    return an, ref


def weapon_anims(k):
    R = D[k]
    an = []
    if k == 'w_ben_BD':
        an = [('machete_walk', [(0, i, False) for i in range(len(R[0]))]),
              ('machete_swing', [(1, i, False) for i in range(len(R[1]))])]
        return an, [(0, i) for i in range(len(R[0]))]
    for r, w in enumerate(['shotgun', 'smg', 'flamer', 'machete']):
        n = len(R[r])
        if w == 'machete':
            sw = 4 if n >= 6 else n // 2
            an += [('machete_walk', [(r, i, False) for i in range(n - sw)]), ('machete_swing', [(r, i, False) for i in range(n - sw, n)])]
        else:
            fc = FIRE[w]
            if n >= 5 + fc:
                an += [(w + '_walk', [(r, i, False) for i in range(4)]), (w + '_aim', [(r, 4, False)]), (w + '_fire', [(r, i, False) for i in range(5, n)])]
            else:
                an += [(w + '_walk', [(r, i, False) for i in range(n - 2)]), (w + '_aim', [(r, n - 2, False)]), (w + '_fire', [(r, n - 1, False)])]
    nm = len(R[3]); sw = 4 if nm >= 6 else nm // 2
    return an, [(3, i) for i in range(nm - sw)]


SPR = {}
for k in D:
    an, ref = (weapon_anims if k.startswith('w_') else base_anims)(k)
    SPR[k] = build(k, an, ref)
    print(k, {a: len(v) for a, v in SPR[k]['s'].items()}, SPR[k]['u'])
json.dump(SPR, open('/home/claude/art/spr_new.json', 'w'), separators=(',', ':'))
